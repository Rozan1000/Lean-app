/**
 * LEAN — motorcycle telemetry dashboard + ride recorder (Expo / React Native)
 *
 * SETUP
 *   npx create-expo-app lean --template blank
 *   cd lean
 *   npx expo install expo-sensors expo-location expo-keep-awake @react-native-async-storage/async-storage
 *   (replace the generated App.js with this file)
 *
 * app.json (inside "expo"):
 *   "orientation": "default",
 *   "userInterfaceStyle": "dark",
 *   "plugins": [
 *     ["expo-location", { "locationWhenInUsePermission": "Used to record speed and route of your ride." }],
 *     ["expo-sensors",  { "motionPermission": "Used to measure the motorcycle's lean angle." }]
 *   ]
 *
 * HOW THE LEAN ANGLE IS MEASURED
 *   An accelerometer alone cannot measure lean on a motorcycle: in a corner, gravity plus
 *   centrifugal force point straight down through the bike, so the phone "feels" upright.
 *   So the angle comes from integrating the gyroscope's roll rate, and the accelerometer is
 *   used only to cancel gyro drift, and only while the bike is going straight (total
 *   acceleration ~1 g and no yaw rotation). That is a gated complementary filter.
 *
 * RIDE LOG DATA STRUCTURE
 *   {
 *     id: "ride_1794300000000",
 *     startedAt: 1794300000000,          // epoch ms
 *     endedAt:   1794303600000,
 *     sampleRateHz: 5,
 *     stats: { maxLeanLeft: 41.2, maxLeanRight: 43.8, maxSpeedKmh: 127.4 },
 *     samples: [
 *       { t: 1794300000200, lat: 52.22977, lon: 21.01178, spd: 63.4, lean: -12.5 },
 *       ...
 *     ]
 *   }
 *   t = epoch ms, spd = km/h, lean = degrees (negative = left, positive = right).
 *   One hour at 5 Hz is 18,000 samples, about 1.3 MB of JSON. For much longer rides switch
 *   to a columnar layout ({ t: [], lat: [], lon: [], spd: [], lean: [] }) or append to a file.
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Alert,
  Platform,
  Pressable,
  Share,
  StatusBar,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { Accelerometer, Gyroscope } from 'expo-sensors';
import * as Location from 'expo-location';
import { useKeepAwake } from 'expo-keep-awake';
import AsyncStorage from '@react-native-async-storage/async-storage';

/* ───────────────────────────── tuning ───────────────────────────── */

const SENSOR_INTERVAL_MS = 20; // 50 Hz sensor loop
const UI_INTERVAL_MS = 50; // 20 Hz screen refresh
const LOG_INTERVAL_MS = 200; // 5 Hz ride log

const ACC_LPF = 0.08; // accelerometer low-pass (kills engine vibration / potholes)
const GYRO_BIAS_LPF = 0.02; // slow average of raw gyro, captured as bias on calibrate
const YAW_LPF = 0.1; // smoothing of yaw rate used by the "going straight" gate
const DRIFT_GAIN = 0.02; // how fast the accelerometer pulls gyro drift back (~1 s)
const DISPLAY_LPF = 0.35; // final smoothing of the number on screen

const STRAIGHT_G_TOLERANCE = 0.05; // |a| must be within 5 % of 1 g
const STRAIGHT_YAW_MAX = 0.04; // rad/s (~2.3 deg/s)
const STRAIGHT_ROLL_MAX = 0.3; // rad/s

// iOS reports gravity pointing down, Android reports it pointing up. Normalise to "up".
const ACC_SIGN = Platform.OS === 'ios' ? -1 : 1;

/* ───────────────────────────── vector math ───────────────────────────── */

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0],
];
const len = (a) => Math.sqrt(dot(a, a));
const normalize = (a) => {
  const l = len(a) || 1;
  return [a[0] / l, a[1] / l, a[2] / l];
};
const RAD2DEG = 180 / Math.PI;

/* ───────────────────────────── lean sensor hook ───────────────────────────── */

function useLeanSensor() {
  // All filter state lives in a ref so the 50 Hz loop never triggers React renders.
  const f = useRef({
    acc: [0, 0, 1], // low-passed accelerometer, in g, pointing "up"
    accSamples: 0,
    gyroAvg: [0, 0, 0], // slow average of raw gyro
    bias: [0, 0, 0], // gyro bias captured at calibration
    up: [0, 0, 1], // bike axes expressed in the phone frame
    right: [1, 0, 0],
    fwd: [0, 1, 0],
    lean: 0, // radians, + = right
    yawLP: 0,
    lastT: null,
    calibrated: false,
  }).current;

  const calibrate = useCallback(() => {
    // "Up" is wherever gravity is right now (bike upright, phone in its mount).
    const up = normalize(f.acc);

    // Work out which screen axis is the bike's left-right axis. This handles portrait,
    // upside-down portrait and both landscape directions without asking the user.
    const seed =
      Math.abs(up[1]) >= Math.abs(up[0])
        ? [Math.sign(up[1]) || 1, 0, 0] // portrait: screen X is lateral
        : [0, -(Math.sign(up[0]) || 1), 0]; // landscape: screen Y is lateral

    // Make it exactly perpendicular to "up" (the mount is usually tilted back).
    const d = dot(seed, up);
    const right = normalize([seed[0] - d * up[0], seed[1] - d * up[1], seed[2] - d * up[2]]);

    f.up = up;
    f.right = right;
    f.fwd = cross(up, right); // roll axis of the bike
    f.bias = [...f.gyroAvg];
    f.lean = 0;
    f.yawLP = 0;
    f.calibrated = true;
  }, [f]);

  useEffect(() => {
    Accelerometer.setUpdateInterval(SENSOR_INTERVAL_MS);
    Gyroscope.setUpdateInterval(SENSOR_INTERVAL_MS);

    const accSub = Accelerometer.addListener(({ x, y, z }) => {
      let a = [x * ACC_SIGN, y * ACC_SIGN, z * ACC_SIGN];
      if (len(a) > 4) a = a.map((v) => v / 9.81); // tolerate m/s² instead of g
      f.acc = [
        f.acc[0] + ACC_LPF * (a[0] - f.acc[0]),
        f.acc[1] + ACC_LPF * (a[1] - f.acc[1]),
        f.acc[2] + ACC_LPF * (a[2] - f.acc[2]),
      ];
      // Auto-zero once after ~1 s so the dashboard works before the first manual calibration.
      f.accSamples += 1;
      if (!f.calibrated && f.accSamples > 50) calibrate();
    });

    const gyroSub = Gyroscope.addListener(({ x, y, z }) => {
      const now = Date.now();
      const dt = f.lastT ? Math.min((now - f.lastT) / 1000, 0.1) : 0;
      f.lastT = now;

      f.gyroAvg = [
        f.gyroAvg[0] + GYRO_BIAS_LPF * (x - f.gyroAvg[0]),
        f.gyroAvg[1] + GYRO_BIAS_LPF * (y - f.gyroAvg[1]),
        f.gyroAvg[2] + GYRO_BIAS_LPF * (z - f.gyroAvg[2]),
      ];
      if (!f.calibrated) return;

      const w = [x - f.bias[0], y - f.bias[1], z - f.bias[2]];
      const rollRate = dot(w, f.fwd);
      const yawRate = dot(w, f.up);
      f.yawLP += YAW_LPF * (yawRate - f.yawLP);

      // 1) Gyro: integrate roll rate. Fast, immune to bumps, but drifts slowly.
      f.lean += rollRate * dt;

      // 2) Accelerometer: correct drift, but only when it can be trusted (riding straight
      //    or standing still). In a corner it reads ~0° lean and must be ignored.
      const g = len(f.acc);
      const goingStraight =
        Math.abs(g - 1) < STRAIGHT_G_TOLERANCE &&
        Math.abs(f.yawLP) < STRAIGHT_YAW_MAX &&
        Math.abs(rollRate) < STRAIGHT_ROLL_MAX;

      if (goingStraight) {
        const accLean = Math.atan2(-dot(f.acc, f.right), dot(f.acc, f.up));
        f.lean += DRIFT_GAIN * (accLean - f.lean);
      }
    });

    return () => {
      accSub.remove();
      gyroSub.remove();
    };
  }, [f, calibrate]);

  const getLeanDeg = useCallback(() => f.lean * RAD2DEG, [f]);
  return { getLeanDeg, calibrate };
}

/* ───────────────────────────── GPS hook ───────────────────────────── */

function useGps() {
  const fix = useRef({ lat: null, lon: null, speedKmh: 0, accuracy: null, t: 0 }).current;
  const [status, setStatus] = useState('WAIT'); // WAIT | OK | DENIED

  useEffect(() => {
    let sub;
    let cancelled = false;
    (async () => {
      const { status: perm } = await Location.requestForegroundPermissionsAsync();
      if (perm !== 'granted') {
        setStatus('DENIED');
        return;
      }
      sub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.BestForNavigation, timeInterval: 1000, distanceInterval: 0 },
        ({ coords, timestamp }) => {
          fix.lat = coords.latitude;
          fix.lon = coords.longitude;
          fix.accuracy = coords.accuracy;
          // speed is m/s; null or negative means "unknown"
          fix.speedKmh = coords.speed != null && coords.speed > 0 ? coords.speed * 3.6 : 0;
          fix.t = timestamp;
          setStatus('OK');
        }
      );
      if (cancelled) sub.remove();
    })();
    return () => {
      cancelled = true;
      if (sub) sub.remove();
    };
  }, [fix]);

  return { fix, status };
}

/* ───────────────────────────── bike graphic (rear view) ───────────────────────────── */

const BIKE_W = 130;
const BIKE_H = 170;

function BikeRear({ angle, color }) {
  // translate → rotate → translate back makes the bike pivot on its tyre contact patch.
  const transform = [
    { translateY: BIKE_H / 2 },
    { rotate: `${angle}deg` },
    { translateY: -BIKE_H / 2 },
  ];
  return (
    <View style={styles.bikeWrap}>
      <View style={[styles.bike, { transform }]}>
        <View style={[styles.helmet, { borderColor: color }]} />
        <View style={[styles.bars, { backgroundColor: color }]} />
        <View style={[styles.torso, { borderColor: color }]} />
        <View style={[styles.tail, { borderColor: color }]}>
          <View style={styles.tailLight} />
        </View>
        <View style={[styles.tyre, { borderColor: color }]} />
      </View>
      <View style={styles.ground} />
    </View>
  );
}

/* ───────────────────────────── app ───────────────────────────── */

const round1 = (v) => Math.round(v * 10) / 10;
const leanColor = (deg) => (deg >= 45 ? '#FF3B30' : deg >= 30 ? '#FFB000' : '#F5F5F5');

export default function App() {
  useKeepAwake(); // the screen must never sleep on the handlebars

  const { width, height } = useWindowDimensions();
  const landscape = width > height;

  const { getLeanDeg, calibrate } = useLeanSensor();
  const { fix, status: gpsStatus } = useGps();

  const [view, setView] = useState({ lean: 0, speed: 0, maxL: 0, maxR: 0, samples: 0 });
  const [recording, setRecording] = useState(false);

  const shown = useRef({ lean: 0, maxL: 0, maxR: 0 }).current;
  const ride = useRef(null);

  // Screen refresh loop (20 Hz) — reads the filter, applies final display smoothing.
  useEffect(() => {
    const id = setInterval(() => {
      shown.lean += DISPLAY_LPF * (getLeanDeg() - shown.lean);
      if (shown.lean < -shown.maxL) shown.maxL = -shown.lean;
      if (shown.lean > shown.maxR) shown.maxR = shown.lean;
      setView({
        lean: shown.lean,
        speed: fix.speedKmh,
        maxL: shown.maxL,
        maxR: shown.maxR,
        samples: ride.current ? ride.current.samples.length : 0,
      });
    }, UI_INTERVAL_MS);
    return () => clearInterval(id);
  }, [getLeanDeg, fix, shown]);

  // Ride logging loop (5 Hz) — only runs while recording.
  useEffect(() => {
    if (!recording) return undefined;
    const id = setInterval(() => {
      const r = ride.current;
      if (!r) return;
      const lean = round1(shown.lean);
      const spd = round1(fix.speedKmh);
      r.samples.push({ t: Date.now(), lat: fix.lat, lon: fix.lon, spd, lean });
      if (-lean > r.stats.maxLeanLeft) r.stats.maxLeanLeft = -lean;
      if (lean > r.stats.maxLeanRight) r.stats.maxLeanRight = lean;
      if (spd > r.stats.maxSpeedKmh) r.stats.maxSpeedKmh = spd;
    }, LOG_INTERVAL_MS);
    return () => clearInterval(id);
  }, [recording, fix, shown]);

  const onCalibrate = () => {
    calibrate();
    shown.lean = 0;
    shown.maxL = 0;
    shown.maxR = 0;
  };

  const startRecording = () => {
    const now = Date.now();
    ride.current = {
      id: `ride_${now}`,
      startedAt: now,
      endedAt: null,
      sampleRateHz: 1000 / LOG_INTERVAL_MS,
      stats: { maxLeanLeft: 0, maxLeanRight: 0, maxSpeedKmh: 0 },
      samples: [],
    };
    shown.maxL = 0;
    shown.maxR = 0;
    setRecording(true);
  };

  const stopRecording = async () => {
    setRecording(false);
    const r = ride.current;
    ride.current = null;
    if (!r) return;
    r.endedAt = Date.now();
    const json = JSON.stringify(r);
    try {
      await AsyncStorage.setItem(r.id, json);
    } catch (e) {
      console.warn('Saving ride failed', e);
    }
    Alert.alert(
      'Ride saved',
      `${r.samples.length} samples\n` +
        `Max lean  L ${r.stats.maxLeanLeft.toFixed(0)}°  R ${r.stats.maxLeanRight.toFixed(0)}°\n` +
        `Max speed ${r.stats.maxSpeedKmh.toFixed(0)} km/h`,
      [{ text: 'Export JSON', onPress: () => Share.share({ title: r.id, message: json }) }, { text: 'OK' }]
    );
  };

  const absLean = Math.abs(view.lean);
  const color = leanColor(absLean);
  const side = absLean < 1 ? '' : view.lean < 0 ? 'L' : 'R';
  const bigFont = Math.min(width, height) * (landscape ? 0.5 : 0.42);

  return (
    <View style={styles.root}>
      <StatusBar hidden />

      {/* top bar: speed + status */}
      <View style={styles.topBar}>
        <View>
          <Text style={styles.label}>SPEED</Text>
          <Text style={styles.speed}>
            {view.speed.toFixed(0)}
            <Text style={styles.unit}> km/h</Text>
          </Text>
        </View>
        <View style={styles.statusCol}>
          <Text style={[styles.status, { color: gpsStatus === 'OK' ? '#00E676' : '#FFB000' }]}>
            GPS {gpsStatus}
          </Text>
          <Text style={[styles.status, { color: recording ? '#FF3B30' : '#555' }]}>
            {recording ? `● REC ${view.samples}` : '○ IDLE'}
          </Text>
        </View>
      </View>

      {/* centre: bike graphic + huge lean number */}
      <View style={[styles.center, landscape && styles.centerLandscape]}>
        <BikeRear angle={view.lean} color={color} />
        <View style={styles.readout}>
          <Text
            style={[styles.lean, { color, fontSize: bigFont, lineHeight: bigFont * 1.05 }]}
            numberOfLines={1}
            adjustsFontSizeToFit
          >
            {absLean.toFixed(0)}°
          </Text>
          <Text style={[styles.side, { color }]}>{side || '—'}</Text>
          <View style={styles.maxRow}>
            <Text style={styles.max}>MAX L {view.maxL.toFixed(0)}°</Text>
            <Text style={styles.max}>MAX R {view.maxR.toFixed(0)}°</Text>
          </View>
        </View>
      </View>

      {/* bottom: big glove-friendly buttons */}
      <View style={styles.buttons}>
        <Pressable
          onPress={onCalibrate}
          style={({ pressed }) => [styles.btn, pressed && styles.btnPressed]}
        >
          <Text style={styles.btnText}>CALIBRATE</Text>
          <Text style={styles.btnHint}>set 0° · bike upright</Text>
        </Pressable>
        <Pressable
          onPress={recording ? stopRecording : startRecording}
          style={({ pressed }) => [
            styles.btn,
            recording ? styles.btnStop : styles.btnRec,
            pressed && styles.btnPressed,
          ]}
        >
          <Text style={[styles.btnText, { color: recording ? '#000' : '#FF3B30' }]}>
            {recording ? 'STOP' : 'START REC'}
          </Text>
          <Text style={[styles.btnHint, recording && { color: '#000' }]}>
            {recording ? 'save ride' : 'log GPS + lean'}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

/* ───────────────────────────── styles ───────────────────────────── */

const MONO = Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' });

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#000',
    paddingHorizontal: 16,
    paddingTop: 28,
    paddingBottom: 20,
  },

  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    borderBottomWidth: 1,
    borderBottomColor: '#222',
    paddingBottom: 8,
  },
  label: { color: '#777', fontFamily: MONO, fontSize: 12, letterSpacing: 2 },
  speed: { color: '#F5F5F5', fontFamily: MONO, fontSize: 44, fontWeight: '700' },
  unit: { color: '#777', fontSize: 16, fontWeight: '400' },
  statusCol: { alignItems: 'flex-end', gap: 6 },
  status: { fontFamily: MONO, fontSize: 14, letterSpacing: 1, fontWeight: '700' },

  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  centerLandscape: { flexDirection: 'row', justifyContent: 'space-evenly' },
  readout: { alignItems: 'center' },
  lean: { fontFamily: MONO, fontWeight: '800', fontVariant: ['tabular-nums'] },
  side: { fontFamily: MONO, fontSize: 28, fontWeight: '800', letterSpacing: 4 },
  maxRow: { flexDirection: 'row', gap: 24, marginTop: 8 },
  max: { color: '#999', fontFamily: MONO, fontSize: 16, letterSpacing: 1 },

  bikeWrap: { width: BIKE_W + 60, height: BIKE_H + 8, alignItems: 'center' },
  bike: { width: BIKE_W, height: BIKE_H, alignItems: 'center' },
  ground: { width: '100%', height: 2, backgroundColor: '#333' },
  helmet: {
    position: 'absolute',
    top: 0,
    width: 34,
    height: 34,
    borderRadius: 17,
    borderWidth: 3,
    backgroundColor: '#000',
  },
  bars: { position: 'absolute', top: 50, width: BIKE_W, height: 5, borderRadius: 2 },
  torso: {
    position: 'absolute',
    top: 32,
    width: 62,
    height: 56,
    borderRadius: 14,
    borderWidth: 3,
    backgroundColor: '#000',
  },
  tail: {
    position: 'absolute',
    top: 84,
    width: 46,
    height: 30,
    borderRadius: 8,
    borderWidth: 3,
    backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tailLight: { width: 22, height: 6, borderRadius: 3, backgroundColor: '#FF3B30' },
  tyre: {
    position: 'absolute',
    bottom: 0,
    width: 30,
    height: 64,
    borderRadius: 15,
    borderWidth: 3,
    backgroundColor: '#111',
  },

  buttons: { flexDirection: 'row', gap: 12 },
  btn: {
    flex: 1,
    minHeight: 84,
    borderWidth: 2,
    borderColor: '#F5F5F5',
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0A0A0A',
  },
  btnRec: { borderColor: '#FF3B30' },
  btnStop: { borderColor: '#FF3B30', backgroundColor: '#FF3B30' },
  btnPressed: { opacity: 0.5 },
  btnText: { color: '#F5F5F5', fontFamily: MONO, fontSize: 22, fontWeight: '800', letterSpacing: 2 },
  btnHint: { color: '#777', fontFamily: MONO, fontSize: 11, marginTop: 4, letterSpacing: 1 },
});
