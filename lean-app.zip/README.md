# Lean

Motorcycle lean-angle dashboard and ride recorder (Expo / React Native, Android).

## Get the APK from GitHub

Every push to `main` builds the APK automatically.
Open the **Actions** tab, pick the latest "Build Android APK" run and download the `lean-apk` artifact.

## Build on your own computer

Needs Node.js 22+, JDK 17 and the Android SDK (Android Studio).

    npm ci && npx expo prebuild -p android && cd android && ./gradlew assembleRelease

The APK is written to `android/app/build/outputs/apk/release/app-release.apk`.
On Windows use `gradlew.bat` instead of `./gradlew`.

## Build in the Expo cloud (no Android Studio)

    npm install -g eas-cli && eas login && eas build -p android --profile preview
